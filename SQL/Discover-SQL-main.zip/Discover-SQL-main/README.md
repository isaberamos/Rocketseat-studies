# Discover SQL
Repositorio com os banco de dados mostrados no curso SQL no [Discover](https://app.rocketseat.com.br/discover)

- Banco de dados inicial: database.sqlite
- Banco de dados escola: escola.sqlite
- Banco de dados funcionario e departamento: unindo_tabelas.sqlite

---
Discover é uma plataforma de cursos gratuita mantida com 💜 pela Rocketseat, entre em nossa comunidade no [Discord](https://discord.gg/7G4mUURTVa)
